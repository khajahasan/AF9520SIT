## VoltMXDB APIs

- [desktopNative.nfi.initializeDatabase](https://github01.hclpnp.com/phoenix-core/desktopnative/new/HPHX-36586/plugin/desktopnativenfis/VoltMXDB#desktopnativenfiinitializedatabase)
- [desktopNative.nfi.closeConnection](https://github01.hclpnp.com/phoenix-core/desktopnative/new/HPHX-36586/plugin/desktopnativenfis/VoltMXDB#desktopnativenficloseConnection)
- [desktopNative.nfi.executeSelectQuery](https://github01.hclpnp.com/phoenix-core/desktopnative/new/HPHX-36586/plugin/desktopnativenfis/VoltMXDB#desktopnativenfiexecuteSelectQuery)
- [desktopNative.nfi.executeSelectPreparedStatement](https://github01.hclpnp.com/phoenix-core/desktopnative/new/HPHX-36586/plugin/desktopnativenfis/VoltMXDB#desktopnativenfiexecuteSelectPreparedStatement)
- [desktopNative.nfi.executeQuery](https://github01.hclpnp.com/phoenix-core/desktopnative/new/HPHX-36586/plugin/desktopnativenfis/VoltMXDB#desktopnativenfiexecuteQuery)
- [desktopNative.nfi.executeRawQuery](https://github01.hclpnp.com/phoenix-core/desktopnative/new/HPHX-36586/plugin/desktopnativenfis/VoltMXDB#desktopnativenfiexecuteRawQuery)
- [desktopNative.nfi.executeQueries](https://github01.hclpnp.com/phoenix-core/desktopnative/new/HPHX-36586/plugin/desktopnativenfis/VoltMXDB#desktopnativenfiexecuteQueries)
- [desktopNative.nfi.executePreparedStatement](https://github01.hclpnp.com/phoenix-core/desktopnative/new/HPHX-36586/plugin/desktopnativenfis/VoltMXDB#desktopnativenfiexecutePreparedStatement)
- [desktopNative.nfi.executeSingleInsertStatement](https://github01.hclpnp.com/phoenix-core/desktopnative/new/HPHX-36586/plugin/desktopnativenfis/VoltMXDB#desktopnativenfiexecuteSingleInsertStatement)
- [desktopNative.nfi.executePreparedStatements](https://github01.hclpnp.com/phoenix-core/desktopnative/new/HPHX-36586/plugin/desktopnativenfis/VoltMXDB#desktopnativenfiexecutePreparedStatements)
- [desktopNative.nfi.executePreparedStatementsAsTransaction](https://github01.hclpnp.com/phoenix-core/desktopnative/new/HPHX-36586/plugin/desktopnativenfis/VoltMXDB#desktopnativenfiexecutePreparedStatementsAsTransaction)

### <ins>desktopNative.nfi.initializeDatabase<ins>

#### Usage

```js
    /**
     * Setup database connection by encrypting DB with the given key.
     * This method should be called before the application setup.
     * i.e. before performing any db operation
     *
     * @param databaseName
     * @param options the options contain the device db encryption key
     *
     * @return {boolean} - return flag which indicate database initialized or not
     */
     desktopNative.nfi.initializeDatabase(databaseName, options);
```

### <ins>desktopNative.nfi.closeConnection<ins>

#### Usage

```js
   /**
    * Closing the database connection
    */
    desktopNative.nfi.closeConnection(dbName);
```

### <ins>desktopNative.nfi.executeSelectQuery</ins>

#### Usage

```js
    /**
     * Executes a raw SQL query
     *
     * @param rawQuery           valid SQL query to execute
     */
    const [err, rows] = await desktopNative.nfi.executeSelectQuery(rawQuery);
```
  
### <ins>desktopNative.nfi.executeSelectPreparedStatement
  
#### Usage
  
```js
    /**
     * TODO: TBD inputs
     * Executes SQL query as a prepared statement
     *
     * @param sqlQuery
     * @param selectionArgs
     *
     * @return a list of values
     */
     desktopNative.nfi.executeSelectPreparedStatement(sqlQuery, selectionArgs);
```
  
### <ins>desktopNative.nfi.executeQuery
  
#### Usage

```js
    /**
     * Executes a valid update SQL statement
     *
     * @param rawQuery valid SQL query to execute. Multiple statements separated by semicolons are not supported.
     */
     desktopNative.nfi.executeQuery(rawQuery);
```  
  
### <ins>desktopNative.nfi.executeQuery
  
#### Usage
  
```js
    /**
     * Executes a raw SQL query
     * @param rawQuery           valid SQL query to execute
     * @param selectionArgs      a list of values to bind to the query
     * @return {Array}           a list of values
     * @throws {Error}            if the raw query is null or empty
     * 
     * @example
     * 
     * const rawQuery = 'SELECT * FROM table WHERE column = ?';
     * const selectionArgs = ['value'];
     * 
     * const result = Nfi.executeRawQuery(rawQuery, selectionArgs);
     * 
     * console.log(result);
     * 
     * // Output: [{ column: 'value' }]
     */
     const [err, result] = await desktopNative.nfi.executeRawQuery(rawQuery, selectionArgs);
```
  
### <ins>desktopNative.nfi.executeQueries
  
#### Usage
  
```js
    /**
     * Executes a list of valid update SQL statements.
     *
     * @param rawQueries        a list of valid SQL queries to execute.
     * @param rollbackOnError    If set to true, entire transaction is rolled back,
     *                           else result of successful queries are persisted to DB
     *                           and failed queries of the current transaction are ignored.
     * @param batchSize          a value for batching the queries.
     */
     desktopNative.nfi.executeQueries(rawQueries, batchSize = Nfi.DEFAULT_BATCH_SIZE, rollbackOnError = false);
```

### <ins>desktopNative.nfi.executePreparedStatement
  
#### Usage
  
```js
    /**
     * Executes SQL query as a prepared statement.
     *
     * @param sqlQuery SQL query
     * @param values needed for constructing a prepared statement
     */
     const [err, result] = await desktopNative.nfi.executePreparedStatement(sqlQuery, values, rollbackOnError);
```
  
### <ins>desktopNative.nfi.executeSingleInsertStatement
  
#### Usage
  
```js
    /**
     * Executes a single INSERT SQL statement and returns the ROW ID of last inserted record in transaction mode
     *
     * @param sqlQuery
     * @param selectionArgs
     *
     * @return rowId of the last inserted record
     */
     const [err, result] = await desktopNative.nfi.executeSingleInsertStatement(sqlQuery, selectionArgs);
```
  
### <ins>desktopNative.nfi.executePreparedStatements
  
#### Usage
  
```js
    /**
     * Executes a list of SQL queries as a prepared statements.
     *
     * @param preparedStatements a list of SQL queries and values needed for constructing a
     *                            prepared statements.
     * @param rollbackOnError     If set to true, entire transaction is rolled back,
     *                            else result of successful queries are persisted to DB
     *                            and failed queries of the current transaction are ignored.
     * @param batchSize           a value for batching the queries.
     */
     const [err, result] = await desktopNative.nfi.executePreparedStatements(preparedStatements, rollbackOnError = false, batchSize = Nfi.DEFAULT_BATCH_SIZE);
```

### <ins>desktopNative.nfi.executePreparedStatementsAsTransaction
  
#### Usage
  
```js
    /**
     * Executes a valid update SQL prepared statements with values in transaction mode i.e either
     * ALL or NONE
     *
     * @param preparedStatements a list of SQL queries and values needed for constructing a
     *                            prepared statements.
     */
     const [err, result] = await desktopNative.nfi.executePreparedStatementsAsTransaction(preparedStatements);
```
