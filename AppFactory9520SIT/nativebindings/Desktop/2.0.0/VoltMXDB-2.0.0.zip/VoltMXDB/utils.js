const path = require('path');
const { app } = require('electron');
const fs = require('fs');

function newResult() {
    return {
        error: undefined,
        value: undefined
    }
}

function getAbsolutePath() {
    return path.join(app.getPath('userData'), 'data');
}

function createDirectory(fullPath) {
    const directory = path.dirname(fullPath);

    if (!fs.existsSync(directory)) {
        fs.mkdirSync(directory, { recursive: true });
    }
}

module.exports = { createDirectory, getAbsolutePath, newResult };
